# ZenithX Token Development

Node version: 20.11.0
npm version: 10.2.5

```
Run: npm i
```

```
For Running the tests:
npx hardhat node
npx hardhat test --network localhost
```